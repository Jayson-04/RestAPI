using GMap.NET;
using GMap.NET.MapProviders;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;

namespace MijnKaart;

public partial class Form1 : Form
{
    private GMapControl map;

    public Form1()
    {
        InitializeComponent();

        Text = "Mijn OpenStreetMap-kaart";
        Width = 1000;
        Height = 700;

        GMaps.Instance.Mode = AccessMode.ServerAndCache;
        GMapProvider.UserAgent = "MijnKaartApp/1.0 (jouw@emailadres.nl)";

        map = new GMapControl
        {
            Dock = DockStyle.Fill,
            MapProvider = GMapProviders.OpenStreetMap,
            MinZoom = 2,
            MaxZoom = 18,
            Zoom = 13,
            Position = new PointLatLng(51.1933903, 5.9882649),
            CanDragMap = true,
            DragButton = MouseButtons.Left,
            ShowCenter = false
        };

        var markers = new GMapOverlay("markers");
        var marker = new GMarkerGoogle(
            new PointLatLng(51.1933903, 5.9882649),
            GMarkerGoogleType.red_dot
        );
        marker.ToolTipText = "Roermond";

        markers.Markers.Add(marker);
        map.Overlays.Add(markers);

        Controls.Add(map);
    }

    private void Form1_Load(object sender, EventArgs e)
    {
    }
}