﻿using GMap.NET;
using GMap.NET.MapProviders;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;
using System;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

public class MapForm : Form
{
    private GMapControl map;

    public MapForm()
    {
        Text = "Mijn OpenStreetMap-kaart";
        Width = 1000;
        Height = 700;

        // Vóór het aanmaken van de kaart instellen
        GMaps.Instance.Mode = AccessMode.ServerAndCache;

        // OSM vereist een User-Agent; gebruik een eigen herkenbare naam
        GMapProvider.UserAgent = "MijnKaartApp/1.0 (jouw@emailadres.nl)";

        map = new GMapControl
        {
            Dock = DockStyle.Fill,
            MapProvider = GMapProviders.OpenStreetMap,
            MinZoom = 2,
            MaxZoom = 18,
            Zoom = 13,
            Position = new PointLatLng(51.1933903, 5.9882649),
            MouseWheelZoomType = MouseWheelZoomType.MousePositionWithoutCenter,
            CanDragMap = true,
            DragButton = MouseButtons.Left,
            ShowCenter = false
        };

        var markers = new GMapOverlay("markers");

        var marker = new GMarkerGoogle(
            new PointLatLng(51.1933903, 5.9882649),
            GMarkerGoogleType.red_dot
        );
        marker.ToolTipText = "Roermond";

        markers.Markers.Add(marker);
        map.Overlays.Add(markers);

        Controls.Add(map);
    }

    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new MapForm());
    }
}