﻿
using System;
using System.Globalization;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        using var client = new HttpClient();

        client.DefaultRequestHeaders.UserAgent.ParseAdd(
            "MijnCSharpLeerproject/1.0 (student)"
        );

        string url =
            "https://nominatim.openstreetmap.org/search?format=json&q=Roermond";

        Console.WriteLine("Gegevens ophalen...");

        string response = await client.GetStringAsync(url);

        using JsonDocument document = JsonDocument.Parse(response);

        JsonElement place = document.RootElement[0];

        string naam = place.GetProperty("name").GetString()!;

        double latitude = double.Parse(
            place.GetProperty("lat").GetString()!,
            CultureInfo.InvariantCulture
        );

        double longitude = double.Parse(
            place.GetProperty("lon").GetString()!,
            CultureInfo.InvariantCulture
        );

        Console.WriteLine($"Naam: {naam}");
        Console.WriteLine($"Latitude: {latitude}");
        Console.WriteLine($"Longitude: {longitude}");

    }
}
